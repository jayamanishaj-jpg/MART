# Elite Mart

A full-stack multi-seller e-commerce capstone inspired by the provided project brief. It implements Buyer, Seller, and Admin roles, product management, search/filtering, cart, checkout, order history, reviews, wishlist, admin controls, and a lightweight shopping assistant.

## Stack
- C++20
- Drogon Web Framework
- SQLite (easy local setup; PostgreSQL can be substituted)
- HTML/CSS/JavaScript
- CMake

The reference requires C++20, Drogon, PostgreSQL/SQLite, GitHub, CMake, HTML/CSS/JavaScript, and the core e-commerce modules. See the supplied brief: fileciteturn0file0L104-L113

## Run
1. Install Drogon and SQLite development libraries.
2. `cmake -S . -B build`
3. `cmake --build build -j`
4. `./build/elite_mart`
5. Open `http://localhost:8080`

Default admin: `admin@elitemart.local` / `admin123`

## Notes
- Payments are intentionally simulated as required by the brief; checkout confirms an order rather than processing real money. fileciteturn0file0L70-L76
- The assistant endpoint is local/rule-based so the project runs without an external API key. It can later be replaced with an LLM API.
