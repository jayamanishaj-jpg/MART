# Elite Mart API

| Method | Endpoint | Purpose |
|---|---|---|
| POST | /api/register | Buyer/Seller registration |
| POST | /api/login | Authentication |
| POST | /api/logout | Logout |
| GET | /api/products | Search/filter products |
| POST | /api/seller/product | Add/edit seller product |
| DELETE | /api/seller/product?id= | Delete seller product |
| GET | /api/cart | View cart |
| POST | /api/cart/add | Add/update cart |
| DELETE | /api/cart?id= | Remove cart item |
| POST | /api/checkout | Confirm order |
| GET | /api/orders | Buyer/seller order history |
| POST | /api/reviews | Add/update review |
| POST | /api/wishlist | Add wishlist item |
| GET | /api/admin/dashboard | Admin overview |
| DELETE | /api/admin/product?id= | Admin remove product |
| POST | /api/chat | Shopping assistant |
